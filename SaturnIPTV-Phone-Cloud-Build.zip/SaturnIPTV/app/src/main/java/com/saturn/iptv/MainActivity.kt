package com.saturn.iptv

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.KeyEvent
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

data class Channel(
    val name: String,
    val streamUrl: String,
    val group: String = "All channels",
    val logo: String? = null
)

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 13, 27)
    private val panel = Color.rgb(17, 27, 49)
    private val blue = Color.rgb(48, 132, 255)
    private val white = Color.rgb(240, 246, 255)
    private val muted = Color.rgb(157, 177, 207)

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var urlInput: EditText
    private lateinit var searchInput: EditText
    private lateinit var channelContainer: LinearLayout
    private lateinit var status: TextView
    private lateinit var count: TextView
    private var channels: List<Channel> = emptyList()
    private var selectedGroup = "All channels"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        playerView.useController = true
        status.text = "Import a playlist to get started"
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
            setBackgroundColor(bg)
        }
        scroll.addView(page)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "◉  SATURN IPTV"
            textSize = 25f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
        }
        page.addView(brand)
        page.addView(label("YOUR STREAMING SPACE  •  ANDROID + FIRE TV", muted, 11f))
        page.addView(space(14))

        playerView = PlayerView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(220)
            )
            setBackgroundColor(Color.BLACK)
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            useController = true
            contentDescription = "Video player"
        }
        page.addView(playerView)
        page.addView(space(12))

        page.addView(label("ADD YOUR PLAYLIST", white, 15f, true))
        urlInput = EditText(this).apply {
            hint = "Paste your M3U playlist URL"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            singleLine = true
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(panel)
            isFocusable = true
            isFocusableInTouchMode = true
        }
        page.addView(urlInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(50)
        ).apply { topMargin = dp(8) })

        val importRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val loadUrl = actionButton("LOAD URL")
        loadUrl.setOnClickListener { loadFromUrl(urlInput.text.toString().trim()) }
        val loadFile = actionButton("OPEN M3U FILE")
        loadFile.setOnClickListener { openPlaylistFile() }
        importRow.addView(loadUrl, weightedParams())
        importRow.addView(loadFile, weightedParams().apply { leftMargin = dp(8) })
        page.addView(importRow)
        page.addView(space(14))

        status = label("Ready", muted, 12f)
        page.addView(status)
        count = label("0 channels", white, 14f, true)
        page.addView(count)
        page.addView(space(10))

        searchInput = EditText(this).apply {
            hint = "Search channels"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            singleLine = true
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(panel)
            addTextChangedListener(SimpleTextWatcher { renderChannels() })
        }
        page.addView(searchInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(48)
        ))
        page.addView(space(8))

        val groupRow = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val groups = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        groupRow.addView(groups)
        page.addView(groupRow)
        groupRow.tag = groups

        channelContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        page.addView(channelContainer)
        renderGroups(groups)
    }

    private fun renderGroups(container: LinearLayout) {
        container.removeAllViews()
        val names = listOf("All channels") + channels.map { it.group }
            .filter { it.isNotBlank() }.distinct().sorted()
        names.forEach { group ->
            val b = actionButton(group.uppercase(Locale.getDefault()))
            b.textSize = 10f
            b.setOnClickListener {
                selectedGroup = group
                renderGroups(container)
                renderChannels()
            }
            if (group == selectedGroup) b.setTextColor(blue)
            container.addView(b, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)
            ).apply { rightMargin = dp(6) })
        }
    }

    private fun renderChannels() {
        if (!::channelContainer.isInitialized) return
        channelContainer.removeAllViews()
        val query = if (::searchInput.isInitialized) searchInput.text.toString().trim() else ""
        val visible = channels.filter {
            (selectedGroup == "All channels" || it.group == selectedGroup) &&
            it.name.contains(query, ignoreCase = true)
        }
        count.text = "${visible.size} channels"
        visible.forEachIndexed { index, channel ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(7), dp(8), dp(7))
                setBackgroundColor(if (index % 2 == 0) panel else bg)
                isFocusable = true
                isFocusableInTouchMode = true
                isClickable = true
                contentDescription = "Play ${channel.name}"
                setOnClickListener { play(channel) }
            }
            val title = TextView(this).apply {
                text = channel.name
                textSize = 14f
                setTextColor(white)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            val subtitle = TextView(this).apply {
                text = channel.group
                textSize = 10f
                setTextColor(muted)
            }
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(title)
                addView(subtitle)
            }
            row.addView(texts, LinearLayout.LayoutParams(0, dp(42), 1f))
            val playButton = actionButton("PLAY")
            playButton.textSize = 11f
            playButton.setOnClickListener { play(channel) }
            row.addView(playButton, LinearLayout.LayoutParams(dp(76), dp(40)))
            channelContainer.addView(row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58)
            ).apply { bottomMargin = dp(4) })
        }
        if (visible.isEmpty()) {
            channelContainer.addView(label(
                if (channels.isEmpty()) "No playlist loaded yet." else "No matching channels.",
                muted, 13f
            ))
        }
    }

    private fun loadFromUrl(raw: String) {
        if (raw.isBlank()) {
            toast("Paste an M3U URL first")
            return
        }
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        if (uri?.scheme !in listOf("http", "https")) {
            toast("Please use a valid http or https URL")
            return
        }
        status.text = "Loading playlist…"
        thread {
            try {
                val connection = URL(raw).openConnection() as HttpURLConnection
                connection.connectTimeout = 15000
                connection.readTimeout = 20000
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "SaturnIPTV/1.0")
                val text = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                connection.disconnect()
                val parsed = parseM3u(text)
                runOnUiThread { acceptPlaylist(parsed) }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Could not load playlist: ${e.message ?: "network error"}"
                    toast("Playlist could not be loaded")
                }
            }
        }
    }

    private fun openPlaylistFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "audio/x-mpegurl", "application/vnd.apple.mpegurl", "text/plain", "application/octet-stream"
            ))
        }
        startActivityForResult(intent, REQUEST_FILE)
    }

    @Deprecated("Use the Activity Result API in a future update")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_FILE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            status.text = "Reading playlist file…"
            thread {
                try {
                    val text = contentResolver.openInputStream(uri)!!.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val parsed = parseM3u(text)
                    runOnUiThread { acceptPlaylist(parsed) }
                } catch (e: Exception) {
                    runOnUiThread { status.text = "Could not read file: ${e.message}" }
                }
            }
        }
    }

    private fun acceptPlaylist(parsed: List<Channel>) {
        channels = parsed
        selectedGroup = "All channels"
        status.text = if (parsed.isEmpty()) "No playable entries found. Check your M3U file." else "Playlist imported successfully"
        val groupContainer = (findGroupContainer())
        groupContainer?.let { renderGroups(it) }
        renderChannels()
        toast("${parsed.size} channels imported")
    }

    private fun findGroupContainer(): LinearLayout? {
        // The group selector is the LinearLayout stored as the tag of its HorizontalScrollView.
        val root = (window.decorView as? ViewGroup) ?: return null
        return findTaggedGroup(root)
    }

    private fun findTaggedGroup(view: View): LinearLayout? {
        if (view is HorizontalScrollView && view.tag is LinearLayout) return view.tag as LinearLayout
        if (view is ViewGroup) for (i in 0 until view.childCount) {
            val found = findTaggedGroup(view.getChildAt(i))
            if (found != null) return found
        }
        return null
    }

    private fun play(channel: Channel) {
        try {
            val item = MediaItem.fromUri(channel.streamUrl)
            player?.setMediaItem(item)
            player?.prepare()
            player?.play()
            status.text = "Now playing: ${channel.name}"
        } catch (e: Exception) {
            status.text = "Cannot play this stream: ${e.message}"
        }
    }

    private fun parseM3u(content: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var name: String? = null
        var group = "Uncategorized"
        var logo: String? = null
        content.lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val comma = line.lastIndexOf(',')
                    name = if (comma >= 0 && comma < line.length - 1) line.substring(comma + 1).trim() else null
                    group = Regex("""group-title=["']([^"']*)["']""", RegexOption.IGNORE_CASE)
                        .find(line)?.groupValues?.get(1)?.ifBlank { "Uncategorized" } ?: "Uncategorized"
                    logo = Regex("""tvg-logo=["']([^"']*)["']""", RegexOption.IGNORE_CASE)
                        .find(line)?.groupValues?.get(1)
                    if (name.isNullOrBlank()) {
                        name = Regex("""tvg-name=["']([^"']*)["']""", RegexOption.IGNORE_CASE)
                            .find(line)?.groupValues?.get(1)
                    }
                }
                line.isNotBlank() && !line.startsWith("#") -> {
                    val stream = line
                    val safeName = name?.takeIf { it.isNotBlank() } ?: "Channel ${result.size + 1}"
                    if (stream.startsWith("http://", true) || stream.startsWith("https://", true)) {
                        result.add(Channel(safeName, stream, group, logo))
                    }
                    name = null
                    group = "Uncategorized"
                    logo = null
                }
            }
        }
        return result
    }

    private fun actionButton(textValue: String): Button = Button(this).apply {
        text = textValue
        textSize = 12f
        isAllCaps = false
        setTextColor(white)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel))
        isFocusable = true
        isFocusableInTouchMode = true
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(10), 0, dp(10), 0)
    }

    private fun label(value: String, color: Int, size: Float, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(3), 0, dp(3))
        }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun weightedParams() = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
        topMargin = dp(8)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_FILE = 4102
    }
}
