# Saturn IPTV

A starter Android / Amazon Fire TV IPTV player for playlists you own or are authorized to use.

## Features in this starter
- Dark navy + blue interface
- M3U playlist import from an HTTP(S) URL
- M3U file import using Android's document picker
- Basic M3U parsing (`#EXTINF`, `group-title`, `tvg-name`, `tvg-logo`)
- Channel search and group filters
- Video playback using AndroidX Media3 / ExoPlayer
- Android TV / Fire TV launcher category and D-pad-focusable controls

## Open and build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder (`SaturnIPTV`) in Android Studio.
3. Use JDK 17 when prompted.
4. Let Gradle sync finish.
5. Select the `app` run configuration and build/run on an Android device or Android TV / Fire TV device.
6. To create an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   The debug APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.

For Fire TV, enable Developer Options / ADB debugging on the device and install the APK using ADB or a trusted sideloading method. The app is also registered with the Android TV launcher category.

## Notes and limitations
- This is a working starter project, not a finished commercial IPTV product.
- It does not include channels, playlists, logos, EPG data, accounts, or any streaming subscriptions.
- Add only playlists and streams that you own or have permission to access.
- Some streams may not play because of unsupported codecs, DRM, server restrictions, expired URLs, or network requirements.
- M3U parsing is intentionally basic. Some providers use non-standard tags or special authentication headers.
- Playlist URLs may contain private access tokens. Do not share them. This starter keeps the playlist only in memory and does not upload it anywhere.
- HTTP streams are permitted for compatibility; HTTPS is safer. Avoid entering playlist URLs from unknown sources.
- Fire TV navigation is supported with focusable buttons and D-pad navigation; a dedicated TV-first layout and additional remote-key polish can be added next.

## Package
`com.saturn.iptv`


## Build without owning a PC (GitHub Actions)
You can trigger a cloud build from a phone:
1. Create a GitHub account and a new repository.
2. Upload the contents of this project folder to the repository (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and allow workflows if GitHub asks.
4. Choose **Build Saturn IPTV APK** and tap **Run workflow** (or push to `main`).
5. Open the completed workflow run, scroll to **Artifacts**, and download `Saturn-IPTV-debug-APK`.
6. Extract the downloaded artifact to get `app-debug.apk`.

This cloud workflow builds the debug APK; it does not publish the app to an app store.
