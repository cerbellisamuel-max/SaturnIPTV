# SATURN IPTV – BLUE EDITION

Kotlin + Jetpack Compose + AndroidX Media3 ExoPlayer. One shared project, three device profiles
(Phone/Tablet, Fire TV, Meta Quest 3/3S). minSdk 23, targetSdk 34.
It is a player only: no channels/playlists are bundled. Use only content you are authorized to access.

## Build the APK
1. Install Android Studio (Koala or newer, JDK 17 is bundled). Open this folder (`SaturnIPTV`).
   Android Studio reads `gradle-wrapper.properties` and downloads Gradle 8.7 + the SDK 34 platform (let it sync).
   (Command line: with Gradle 8.7 installed run `gradle wrapper` once, then use `./gradlew`.)
2. Build > Build Bundle(s) / APK(s) > Build APK(s), or:
   `./gradlew assembleDebug`  ->  `app/build/outputs/apk/debug/app-debug.apk`
   `./gradlew assembleRelease` -> `app/build/outputs/apk/release/app-release.apk` (debug-signed, installable)

## Install on Fire TV Stick
1. Fire TV: Settings > My Fire TV > Developer Options > ADB debugging ON, Install unknown apps ON
   (on newer Fire OS: Settings > My Fire TV > About > tap the device name 7 times first).
2. Note the IP: Settings > My Fire TV > About > Network.
3. On your PC: `adb connect <FIRE_TV_IP>:5555` (accept the prompt on the TV), then
   `adb install -r app-debug.apk`
   Alternative: upload the APK to a cloud link and open it with the "Downloader" app on the Fire TV.
4. Launch from Apps & Channels > SATURN IPTV. Choose "Amazon Fire TV Stick" on first start.
   Remote: D-pad moves the glowing focus, Select opens, Long-press Select toggles favorite, Back leaves the player.

## Test on Meta Quest 3 / 3S
1. Create a developer account at developers.meta.com, then in the Meta Horizon phone app:
   Devices > your headset > Developer Mode ON.
2. Connect the headset by USB-C (allow USB debugging in the headset), then `adb install -r app-debug.apk`
   (wireless: `adb tcpip 5555`, `adb connect <QUEST_IP>:5555`).
3. In the headset: Library > filter "Unknown Sources" > SATURN IPTV. Choose "Meta Quest 3 / Quest 3S".
   The app runs as a landscape 2D window in Horizon OS; point and trigger with the controller (large buttons).
NOTE: this is a normal Android app, NOT a native immersive VR app. For true VR/360/cinema-room rendering,
build a separate Unity + OpenXR project.

## Using it
Settings > Playlists: add an M3U URL, or import a local .m3u/.m3u8 file. Group titles become categories,
tvg-logo becomes the channel image. Entries are sorted into Live / Movies / Series by group name or URL path.
Playlists are cached on the device. Long-press (or heart icon) = favorite. Recently watched is automatic.
