package com.saturn.iptv

import android.content.pm.ActivityInfo
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(vm: AppVm, req: PlayRequest, device: Device) {
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    val offset = (req.index - 250).coerceAtLeast(0)
    val window = remember { req.list.drop(offset).take(500) }
    val startIdx = req.index - offset

    var error by remember { mutableStateOf<String?>(null) }
    var title by remember { mutableStateOf(window.getOrNull(startIdx)?.name ?: "") }
    var current by remember { mutableStateOf(window.getOrNull(startIdx)) }
    var ctrlVisible by remember { mutableStateOf(true) }
    val player = remember { ExoPlayer.Builder(ctx).build() }
    val landscapeDefault = if (device == Device.PHONE) ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

    BackHandler { vm.playing = null }

    DisposableEffect(player) {
        var retries = 0
        val handler = Handler(Looper.getMainLooper())
        val listener = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) {
                error = "Can't play this stream (${e.errorCodeName})"
                if (vm.autoRetry && retries < 3) {
                    retries++
                    handler.postDelayed({ player.prepare() }, 3000)
                }
            }
            override fun onMediaItemTransition(m: MediaItem?, reason: Int) {
                retries = 0; error = null
                window.getOrNull(player.currentMediaItemIndex)?.let { current = it; title = it.name; vm.markPlayed(it) }
            }
            override fun onPlaybackStateChanged(s: Int) {
                if (s == Player.STATE_READY) { error = null; retries = 0 }
            }
        }
        player.addListener(listener)
        player.setMediaItems(window.map { MediaItem.fromUri(it.url) }, startIdx, 0L)
        player.prepare()
        player.playWhenReady = true
        window.getOrNull(startIdx)?.let { vm.markPlayed(it) }

        val w = activity.window
        val bars = WindowCompat.getInsetsController(w, w.decorView)
        bars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        bars.hide(WindowInsetsCompat.Type.systemBars())

        onDispose {
            handler.removeCallbacksAndMessages(null)
            player.removeListener(listener)
            player.release()
            bars.show(WindowInsetsCompat.Type.systemBars())
            activity.requestedOrientation = landscapeDefault
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                PlayerView(c).apply {
                    this.player = player
                    useController = true
                    keepScreenOn = true
                    isFocusable = true
                    controllerShowTimeoutMs = 4000
                    setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                    setShowNextButton(true)
                    setShowPreviousButton(true)
                    setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
                        ctrlVisible = v == View.VISIBLE
                    })
                    setFullscreenButtonClickListener(PlayerView.FullscreenButtonClickListener { fs ->
                        activity.requestedOrientation =
                            if (fs) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else landscapeDefault
                    })
                    post { requestFocus() }
                }
            },
            update = {
                it.resizeMode = listOf(
                    AspectRatioFrameLayout.RESIZE_MODE_FIT,
                    AspectRatioFrameLayout.RESIZE_MODE_FILL,
                    AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                )[vm.resizeMode.coerceIn(0, 2)]
            }
        )

        if (ctrlVisible || error != null) {
            Row(
                Modifier.fillMaxWidth().background(Color(0x99000000)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.playing = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                current?.let { c ->
                    val fav = c.id in vm.favorites
                    IconButton(onClick = { vm.toggleFav(c) }) {
                        Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favorite", tint = LocalAccent.current)
                    }
                }
            }
        }

        error?.let { msg ->
            Column(
                Modifier.align(Alignment.Center).background(Color(0xCC040814)).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(msg, color = Color.White, fontSize = 16.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SButton("Retry", Icons.Filled.Refresh) { error = null; player.prepare(); player.play() }
                    SButton("Next channel", Icons.Filled.SkipNext) {
                        error = null; player.seekToNextMediaItem(); player.prepare(); player.play()
                    }
                    SButton("Close") { vm.playing = null }
                }
            }
        }
    }
}
