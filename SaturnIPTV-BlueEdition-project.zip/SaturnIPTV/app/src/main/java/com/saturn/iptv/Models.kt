package com.saturn.iptv

enum class Device(val label: String) {
    PHONE("Android Phone / Tablet"),
    TV("Amazon Fire TV Stick"),
    QUEST("Meta Quest 3 / Quest 3S")
}

enum class Kind { LIVE, MOVIE, SERIES }

data class Channel(
    val id: String, val name: String, val url: String,
    val logo: String?, val group: String, val kind: Kind
)

data class Playlist(val id: String, val name: String, val source: String, val isUrl: Boolean)

class PlayRequest(val list: List<Channel>, val index: Int)

object M3uParser {
    private val attr = Regex("""([\w-]+)="([^"]*)"""")
    private val seriesRx = Regex("series|tv show")
    private val movieRx = Regex("movie|film|vod|cinema")

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        var name: String? = null
        var logo: String? = null
        var group = "Uncategorized"
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", true) -> {
                    val a = attr.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    logo = a["tvg-logo"]?.takeIf { it.isNotBlank() }
                    group = a["group-title"]?.takeIf { it.isNotBlank() } ?: "Uncategorized"
                    name = line.substringAfterLast(',', a["tvg-name"] ?: "").trim().ifBlank { a["tvg-name"] ?: "Channel" }
                }
                line.startsWith("#EXTGRP:", true) -> group = line.substringAfter(':').trim().ifBlank { group }
                line.isEmpty() || line.startsWith("#") -> Unit
                else -> if (name != null) {
                    out.add(Channel("${name}|$line".hashCode().toString(), name, line, logo, group, classify(line, group)))
                    name = null; logo = null; group = "Uncategorized"
                }
            }
        }
        return out
    }

    private fun classify(url: String, group: String): Kind {
        val u = url.lowercase(); val g = group.lowercase()
        return when {
            "/series/" in u || seriesRx.containsMatchIn(g) -> Kind.SERIES
            "/movie/" in u || movieRx.containsMatchIn(g) -> Kind.MOVIE
            else -> Kind.LIVE
        }
    }
}
