package com.saturn.iptv

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SaturnApp(viewModel()) }
    }
}

@androidx.compose.runtime.Composable
fun SaturnApp(vm: AppVm) {
    val ctx = LocalContext.current
    val accent = Accents[vm.accentIndex.coerceIn(0, Accents.lastIndex)].second
    val device = vm.device

    LaunchedEffect(device) {
        (ctx as? ComponentActivity)?.requestedOrientation =
            if (device == Device.PHONE || device == null) ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }
    LaunchedEffect(vm.message) {
        vm.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); vm.message = null }
    }

    CompositionLocalProvider(LocalAccent provides accent) {
        MaterialTheme(colorScheme = darkColorScheme(primary = accent, background = Bg, surface = Navy,
            onSurface = Color.White, onBackground = Color.White)) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg, Navy, Bg)))) {
                val req = vm.playing
                when {
                    device == null -> DeviceSelect { vm.setDevice(it) }
                    req != null -> PlayerScreen(vm, req, device)
                    else -> Home(vm, device)
                }
                if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter), color = accent)
            }
        }
    }
}
