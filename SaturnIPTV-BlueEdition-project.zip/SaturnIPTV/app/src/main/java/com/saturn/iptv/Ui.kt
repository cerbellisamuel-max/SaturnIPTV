@file:OptIn(ExperimentalFoundationApi::class)

package com.saturn.iptv

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Bg = Color(0xFF040814)
val Navy = Color(0xFF0A1530)
val CardC = Color(0xFF101D3D)
val Muted = Color(0xFF8FA6D6)
val LocalAccent = compositionLocalOf { Color(0xFF2D8CFF) }
val Accents = listOf("Blue" to Color(0xFF2D8CFF), "Cyan" to Color(0xFF18E0FF), "Violet" to Color(0xFF8A5CFF))

@Composable
fun SaturnLogo(sz: Dp) {
    val a = LocalAccent.current
    Canvas(Modifier.size(sz)) {
        val c = center
        val m = this.size.minDimension
        val r = m * 0.26f
        val tl = Offset(c.x - r * 2.2f, c.y - r * 0.62f)
        val sz2 = Size(r * 4.4f, r * 1.24f)
        val st = Stroke(m * 0.05f)
        rotate(-20f, c) { drawOval(a.copy(alpha = .85f), tl, sz2, style = st) }
        drawCircle(
            Brush.radialGradient(listOf(Color.White, a, Color(0xFF0A2A66)), Offset(c.x - r * .3f, c.y - r * .3f), r * 1.6f),
            r, c
        )
        rotate(-20f, c) { drawArc(Color(0xFF7CC0FF), 0f, 180f, false, tl, sz2, style = st) }
    }
}

@Composable
fun Modifier.glow(
    shape: Shape = RoundedCornerShape(18.dp),
    onLong: (() -> Unit)? = null,
    onClick: () -> Unit
): Modifier {
    val accent = LocalAccent.current
    var f by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (f) 1.06f else 1f, label = "scale")
    val bc by animateColorAsState(if (f) accent else accent.copy(alpha = .22f), label = "border")
    return this
        .onFocusChanged { f = it.isFocused }
        .scale(s)
        .border(if (f) 3.dp else 1.dp, bc, shape)
        .clip(shape)
        .combinedClickable(onLongClick = onLong, onClick = onClick)
}

@Composable
fun SButton(
    text: String, icon: ImageVector? = null, selected: Boolean = false,
    modifier: Modifier = Modifier, onClick: () -> Unit
) {
    val a = LocalAccent.current
    Row(
        modifier.glow(RoundedCornerShape(14.dp), onClick = onClick)
            .background(if (selected) a.copy(alpha = .35f) else CardC)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = a, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
fun DeviceSelect(onPick: (Device) -> Unit) {
    val a = LocalAccent.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    val items = listOf(Device.PHONE to Icons.Filled.Smartphone, Device.TV to Icons.Filled.Tv, Device.QUEST to Icons.Filled.ViewInAr)
    BoxWithConstraints(Modifier.fillMaxSize().padding(24.dp)) {
        val wide = maxWidth > 700.dp
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            SaturnLogo(96.dp)
            Text("SATURN IPTV", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
            Text("BLUE EDITION", color = a, fontSize = 12.sp, letterSpacing = 6.sp)
            Spacer(Modifier.height(10.dp))
            Text("Welcome! Which device are you using?", color = Muted, fontSize = 18.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(28.dp))
            if (wide) Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                items.forEachIndexed { i, (d, ic) ->
                    DeviceCard(d, ic, Modifier.weight(1f).then(if (i == 0) Modifier.focusRequester(fr) else Modifier), onPick)
                }
            } else Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items.forEachIndexed { i, (d, ic) ->
                    DeviceCard(d, ic, Modifier.fillMaxWidth().then(if (i == 0) Modifier.focusRequester(fr) else Modifier), onPick)
                }
            }
        }
    }
}

@Composable
private fun DeviceCard(d: Device, icon: ImageVector, modifier: Modifier, onPick: (Device) -> Unit) {
    val a = LocalAccent.current
    Column(
        modifier.glow(RoundedCornerShape(24.dp)) { onPick(d) }
            .background(Brush.verticalGradient(listOf(CardC, Navy)))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = a, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(12.dp))
        Text(d.label, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}
