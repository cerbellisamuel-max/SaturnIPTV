package com.saturn.iptv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Store(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("saturn_iptv", Context.MODE_PRIVATE)

    var device: Device?
        get() = p.getString("device", null)?.let { n -> Device.values().firstOrNull { it.name == n } }
        set(v) { p.edit().putString("device", v?.name).apply() }
    var activeId: String?
        get() = p.getString("active", null)
        set(v) { p.edit().putString("active", v).apply() }
    var accent: Int
        get() = p.getInt("accent", 0)
        set(v) { p.edit().putInt("accent", v).apply() }
    var resize: Int
        get() = p.getInt("resize", 0)
        set(v) { p.edit().putInt("resize", v).apply() }
    var autoRetry: Boolean
        get() = p.getBoolean("retry", true)
        set(v) { p.edit().putBoolean("retry", v).apply() }
    var favorites: Set<String>
        get() = (p.getStringSet("fav", emptySet()) ?: emptySet()).toSet()
        set(v) { p.edit().putStringSet("fav", v).apply() }
    var recents: List<String>
        get() = (p.getString("recent", "") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { p.edit().putString("recent", v.joinToString(",")).apply() }

    fun playlists(): List<Playlist> {
        val a = JSONArray(p.getString("playlists", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Playlist(o.getString("id"), o.getString("name"), o.getString("source"), o.getBoolean("isUrl"))
        }
    }

    fun savePlaylists(l: List<Playlist>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("source", it.source).put("isUrl", it.isUrl)) }
        p.edit().putString("playlists", a.toString()).apply()
    }

    private fun file(id: String) = File(ctx.filesDir, "pl_$id.m3u")
    fun saveText(id: String, t: String) = file(id).writeText(t)
    fun readText(id: String): String = file(id).takeIf { it.exists() }?.readText() ?: ""
    fun deleteText(id: String) { file(id).delete() }
}
