package com.saturn.iptv

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class AppVm(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var device by mutableStateOf(store.device); private set
    var playlists by mutableStateOf(store.playlists()); private set
    var activeId by mutableStateOf(store.activeId); private set
    var channels by mutableStateOf<List<Channel>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var favorites by mutableStateOf(store.favorites()); private set
    var recents by mutableStateOf(store.recents()); private set
    var accentIndex by mutableStateOf(store.accent); private set
    var resizeMode by mutableStateOf(store.resize); private set
    var autoRetry by mutableStateOf(store.autoRetry); private set
    var message by mutableStateOf<String?>(null)
    var playing by mutableStateOf<PlayRequest?>(null)
    var section by mutableStateOf(Section.LIVE); private set
    var query by mutableStateOf("")
    var category by mutableStateOf<String?>(null)

    init { loadActive() }

    fun selectSection(s: Section) { section = s; query = ""; category = null }
    fun setDevice(d: Device) { device = d; store.device = d }
    fun setAccent(i: Int) { accentIndex = i; store.accent = i }
    fun setResize(i: Int) { resizeMode = i; store.resize = i }
    fun toggleRetry() { autoRetry = !autoRetry; store.autoRetry = autoRetry }

    fun toggleFav(c: Channel) {
        favorites = if (c.id in favorites) favorites - c.id else favorites + c.id
        store.favorites = favorites
    }

    fun markPlayed(c: Channel) {
        recents = (listOf(c.id) + recents.filter { it != c.id }).take(40)
        store.recents = recents
    }

    private fun loadActive() {
        val p = playlists.firstOrNull { it.id == activeId } ?: playlists.firstOrNull() ?: return
        use(p)
    }

    fun use(p: Playlist) {
        viewModelScope.launch {
            loading = true
            try {
                val ch = withContext(Dispatchers.IO) { M3uParser.parse(store.readText(p.id)) }
                activate(p.id, ch)
            } catch (e: Exception) { message = "Error: ${e.message}" }
            loading = false
        }
    }

    private fun activate(id: String, ch: List<Channel>) {
        activeId = id; store.activeId = id; channels = ch
    }

    fun addUrl(name: String, url: String) {
        val u = url.trim()
        if (!u.startsWith("http://") && !u.startsWith("https://")) { message = "Enter a valid http(s) playlist URL"; return }
        import(null, name, u, true) { download(u) }
    }

    fun refresh(p: Playlist) { if (p.isUrl) import(p.id, p.name, p.source, true) { download(p.source) } }

    fun addFile(uri: Uri) {
        val ctx = getApplication<Application>()
        var name = "Imported playlist"
        ctx.contentResolver.query(uri, null, null, null, null)?.use {
            val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && it.moveToFirst()) name = it.getString(i).substringBeforeLast('.')
        }
        import(null, name, "File: $name", false) {
            ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: error("Cannot open file")
        }
    }

    fun delete(p: Playlist) {
        playlists = playlists.filter { it.id != p.id }
        store.savePlaylists(playlists); store.deleteText(p.id)
        if (activeId == p.id) {
            activeId = null; store.activeId = null; channels = emptyList()
            loadActive()
        }
    }

    private fun import(id: String?, name: String, source: String, isUrl: Boolean, fetch: () -> String) {
        viewModelScope.launch {
            loading = true
            try {
                val (p, ch) = withContext(Dispatchers.IO) {
                    val text = fetch()
                    val ch = M3uParser.parse(text)
                    require(ch.isNotEmpty()) { "No channels found in this playlist" }
                    val p = Playlist(id ?: UUID.randomUUID().toString(), name.ifBlank { "Playlist" }, source, isUrl)
                    store.saveText(p.id, text)
                    p to ch
                }
                playlists = playlists.filter { it.id != p.id } + p
                store.savePlaylists(playlists)
                activate(p.id, ch)
                message = "Loaded ${ch.size} channels"
            } catch (e: Exception) {
                message = "Error: ${e.message ?: e.javaClass.simpleName}"
            }
            loading = false
        }
    }

    private fun download(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "SaturnIPTV/1.0")
        try {
            if (c.responseCode !in 200..299) error("Server answered HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }
}
