@file:OptIn(ExperimentalFoundationApi::class)

package com.saturn.iptv

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

enum class Section(val label: String, val icon: ImageVector) {
    LIVE("Live TV", Icons.Filled.LiveTv),
    MOVIES("Movies", Icons.Filled.Movie),
    SERIES("Series", Icons.Filled.VideoLibrary),
    FAVS("Favorites", Icons.Filled.Favorite),
    RECENT("Recent", Icons.Filled.History),
    SETTINGS("Settings", Icons.Filled.Settings)
}

@Composable
fun Home(vm: AppVm, device: Device) {
    val base = LocalDensity.current
    val k = when (device) { Device.PHONE -> 1f; Device.TV -> 1.2f; Device.QUEST -> 1.3f }
    val a = LocalAccent.current
    CompositionLocalProvider(LocalDensity provides Density(base.density * k, base.fontScale)) {
        val sec = vm.section
        val body: @Composable (Modifier) -> Unit = { m ->
            Box(m) {
                if (sec == Section.SETTINGS) SettingsScreen(vm, device)
                else ChannelScreen(vm, sec, device)
            }
        }
        if (device == Device.PHONE) {
            Column(Modifier.fillMaxSize()) {
                body(Modifier.weight(1f))
                NavigationBar(containerColor = Navy) {
                    Section.values().forEach { t ->
                        NavigationBarItem(
                            selected = sec == t, onClick = { vm.selectSection(t) },
                            icon = { Icon(t.icon, t.label) },
                            label = { Text(t.label, maxLines = 1, fontSize = 10.sp) },
                            alwaysShowLabel = false,
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White, selectedTextColor = a,
                                indicatorColor = a.copy(alpha = .45f), unselectedIconColor = Muted
                            )
                        )
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxSize()) {
                Column(
                    Modifier.width(210.dp).fillMaxHeight().background(Color(0x99060D20))
                        .verticalScroll(rememberScrollState()).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SaturnLogo(44.dp); Spacer(Modifier.width(8.dp))
                        Column {
                            Text("SATURN", color = Color.White, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                            Text("BLUE EDITION", color = a, fontSize = 9.sp, letterSpacing = 2.sp)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Section.values().forEach { t ->
                        SButton(t.label, t.icon, sec == t, Modifier.fillMaxWidth()) { vm.selectSection(t) }
                    }
                }
                body(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun ChannelCard(
    c: Channel, fav: Boolean, tv: Boolean, modifier: Modifier,
    onPlay: () -> Unit, onFav: () -> Unit
) {
    val a = LocalAccent.current
    Column(modifier.glow(RoundedCornerShape(16.dp), onLong = onFav, onClick = onPlay).background(CardC)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Navy), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.LiveTv, null, tint = a.copy(alpha = .35f), modifier = Modifier.size(36.dp))
            if (c.logo != null) AsyncImage(
                model = c.logo, contentDescription = c.name, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(10.dp)
            )
            Box(Modifier.align(Alignment.TopEnd)) {
                val ic = if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder
                if (tv) { if (fav) Icon(ic, null, tint = a, modifier = Modifier.padding(6.dp).size(20.dp)) }
                else IconButton(onClick = onFav, modifier = Modifier.size(40.dp)) { Icon(ic, "Favorite", tint = a) }
            }
        }
        Column(Modifier.padding(10.dp)) {
            Text(c.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(c.group, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun ChannelScreen(vm: AppVm, sec: Section, device: Device) {
    val a = LocalAccent.current
    val all = vm.channels
    val favs = vm.favorites
    val recents = vm.recents
    val base = remember(all, sec, favs, recents) {
        when (sec) {
            Section.LIVE -> all.filter { it.kind == Kind.LIVE }
            Section.MOVIES -> all.filter { it.kind == Kind.MOVIE }
            Section.SERIES -> all.filter { it.kind == Kind.SERIES }
            Section.FAVS -> all.filter { it.id in favs }
            else -> { val m = all.associateBy { it.id }; recents.mapNotNull { m[it] } }
        }
    }
    val q = vm.query
    val cat = vm.category
    val shown = remember(base, q, cat) {
        base.filter { (cat == null || it.group == cat) && (q.isBlank() || it.name.contains(q.trim(), true)) }
    }
    val groups = remember(base) { base.map { it.group }.distinct().sorted() }
    val tv = device == Device.TV
    val play: (Channel) -> Unit = { c -> vm.playing = PlayRequest(shown, shown.indexOf(c).coerceAtLeast(0)) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(sec.label, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            Text("${shown.size} items", color = Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = q, onValueChange = { vm.query = it }, singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search channels…", color = Muted) },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = a) },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = a, unfocusedBorderColor = a.copy(alpha = .3f),
                focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = a,
                focusedContainerColor = CardC, unfocusedContainerColor = CardC
            )
        )
        if (!tv && groups.size > 1) {
            LazyRow(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { SButton("All", null, cat == null) { vm.category = null } }
                items(groups) { g -> SButton(g, null, cat == g) { vm.category = g } }
            }
        } else Spacer(Modifier.height(10.dp))

        when {
            vm.playlists.isEmpty() -> Column(
                Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SaturnLogo(72.dp)
                Text("No playlist yet", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Add your own M3U URL or file to get started.", color = Muted)
                Spacer(Modifier.height(14.dp))
                SButton("Add playlist", Icons.Filled.Add) { vm.selectSection(Section.SETTINGS) }
            }
            shown.isEmpty() -> Text(
                if (sec == Section.FAVS) "Long-press (or tap the heart) on a channel to add favorites."
                else if (sec == Section.RECENT) "Nothing watched yet." else "No matching items.", color = Muted
            )
            tv -> {
                val grouped = remember(shown, sec) {
                    if (sec == Section.RECENT) listOf("Recently watched" to shown) else shown.groupBy { it.group }.toList()
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(grouped) { (g, list) ->
                        Text(g, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 10.dp)
                        ) {
                            items(list) { c ->
                                ChannelCard(c, c.id in favs, true, Modifier.width(230.dp), { play(c) }, { vm.toggleFav(c) })
                            }
                        }
                    }
                }
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(if (device == Device.QUEST) 200.dp else 150.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(shown) { c -> ChannelCard(c, c.id in favs, false, Modifier, { play(c) }, { vm.toggleFav(c) }) }
            }
        }
    }
}

@Composable
private fun H(t: String) {
    Text(t, color = LocalAccent.current, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
        modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
}

@Composable
fun SettingsScreen(vm: AppVm, device: Device) {
    val a = LocalAccent.current
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.addFile(uri) }
    val fc = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = a, unfocusedBorderColor = a.copy(alpha = .3f),
        focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = a,
        focusedContainerColor = CardC, unfocusedContainerColor = CardC
    )

    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item { Text("Settings", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black) }

        item { H("DEVICE PROFILE") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Device.values().forEach { d -> SButton(d.label, null, device == d, Modifier.fillMaxWidth()) { vm.setDevice(d) } }
            }
        }

        item { H("PLAYLISTS") }
        items(vm.playlists) { p ->
            Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(14.dp)).background(CardC).padding(12.dp)) {
                Text(p.name + if (p.id == vm.activeId) "  •  ACTIVE" else "", color = Color.White, fontWeight = FontWeight.Bold)
                Text(p.source, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SButton("Use", Icons.Filled.PlayArrow) { vm.use(p) }
                    if (p.isUrl) SButton("Refresh", Icons.Filled.Refresh) { vm.refresh(p) }
                    SButton("Delete", Icons.Filled.Delete) { vm.delete(p) }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, colors = fc,
                    label = { Text("Playlist name") }, shape = RoundedCornerShape(14.dp))
                OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), singleLine = true, colors = fc,
                    label = { Text("M3U URL (http/https)") }, shape = RoundedCornerShape(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SButton("Add from URL", Icons.Filled.Link) { vm.addUrl(name, url); url = ""; name = "" }
                    SButton("Import M3U file", Icons.Filled.FolderOpen) { picker.launch(arrayOf("*/*")) }
                }
            }
        }

        item { H("PLAYER") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Fit", "Fill", "Zoom").forEachIndexed { i, n ->
                        SButton("Video: $n", null, vm.resizeMode == i) { vm.setResize(i) }
                    }
                }
                SButton("Auto-retry on error: ${if (vm.autoRetry) "ON" else "OFF"}", null, vm.autoRetry) { vm.toggleRetry() }
            }
        }

        item { H("THEME") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Accents.forEachIndexed { i, (n, _) -> SButton(n, null, vm.accentIndex == i) { vm.setAccent(i) } }
            }
        }

        item { H("ABOUT") }
        item {
            Text("SATURN IPTV – BLUE EDITION\nVersion 1.0\nA player only: no channels or playlists are included. " +
                "Use only playlists and streams you are authorized to access.", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(30.dp))
        }
    }
}
